package main;

import control.*;
import static java.awt.SystemColor.control;

/**
 * main class
 * @author aibak aljdayah
 * @version JDK 1.8
 */
public class Main {
  
   
    /**
     * is the main 
     * @param args this the command line arguments
     * @throws java.lang.Exception this throw when error happend
     */
    public static void main(String[] args) throws Exception {
        
     int rowSize1;
     int rowSize2;
     int columSize1;
     int columSize2;
     try
     {
      rowSize1=Integer.parseInt(args[0]);
     }catch (Exception e)
     {
         rowSize1=0;
     }
     try
     {
        
      rowSize2=Integer.parseInt(args[1]);
     }catch (Exception e)
     {
         rowSize2=0;
     }
     try
     {
       
      columSize1=Integer.parseInt(args[2]);
     }catch(Exception e)
     {
         columSize1=0;
     }
     try
     {
  
        
      columSize2=Integer.parseInt(args[3]);
     }catch (Exception e)
     {
         columSize2=0;
     }
   
    Control control=new Control();
    
   
    if(args.length==4)
    {
    
    control.control(rowSize1,rowSize2,columSize1,columSize2);
    }
  
    else
    {
        
        control.wrong();
    }
    
  }
}
