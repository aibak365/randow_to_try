package model;
import control.*;
/**
 *@version JDK 1.8
 * @author ai365ak
 */
public class Error extends Exception {
    /**
     * create a new object of control
     */
    Control control=new Control();

    /**
     * this the constructor
     */
    public Error()
    {
        control.wrongError();
    }
    
}
